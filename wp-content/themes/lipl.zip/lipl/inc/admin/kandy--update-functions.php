<?php

/*
*	Theme update functions
*
 * 	@version	1.0
 * 	@author		Euthemians Team
 * 	@URI		http://euthemians.com
*/

/**
 * Display theme update notices in the admin area
 */
function corpus_eutf_admin_notices() {

	$message = '';
	if ( is_super_admin() ) {

		if ( ( defined( 'CORPUS_EXT_VERSION' ) && version_compare( '3.0', CORPUS_EXT_VERSION, '>' ) ) && !get_user_meta( get_current_user_id(), 'corpus_eutf_dismissed_notice_update_plugins', true ) ) {

		$plugins_link = 'admin.php?page=corpus-tgmpa-install-plugins';
			$message = esc_html__( "Note: Corpus v3 is a major theme release so be sure to update the required plugins, especially Corpus Extension, to avoid any compatibility issues.", 'corpus' ) .
						" <a href='" . esc_url( admin_url() . $plugins_link ) . "'>" . esc_html__( "Theme Plugins", 'corpus' ) . "</a>";
			$message .=  '<br/><span><a href="' .esc_url( wp_nonce_url( add_query_arg( 'corpus-eutf-dismiss', 'dismiss_update_plugins_notice' ), 'corpus-eutf-dismiss-' . esc_attr( get_current_user_id() ) ) ) . '" class="dismiss-notice" target="_parent">' . esc_html__( "Dismiss this notice", 'corpus' ) . '</a><span>';
			add_settings_error(
				'eut-theme-update-message',
				'plugins_update_required',
				$message,
				'updated'
			);
			if ( 'options-general' !== $GLOBALS['current_screen']->parent_base ) {
				settings_errors( 'eut-theme-update-message' );
			}

		}

		if ( !class_exists( 'Envato_Market' ) && !get_user_meta( get_current_user_id(), 'corpus_eutf_dismissed_notice_envato_market', true ) ) {

			$envato_market_link = 'admin.php?page=corpus-tgmpa-install-plugins';
			$message = esc_html__( "Note:", "corpus" ) . " " . esc_html__( "Envato official solution is recommended for theme updates using the new Envato Market API.", 'corpus' ) .
					"<br/>" . esc_html__( "You can now update the theme using the", 'corpus' ) . " " . "<a href='" . esc_url( admin_url() . $envato_market_link ) . "'>" . esc_html__( "Envato Market", 'corpus' ) . "</a>" . " ". esc_html__( "plugin", 'corpus' ) . "." .
					" " . esc_html__( "For more information read the related article in our", 'corpus' ) . " " . "<a href='//docs.euthemians.com/tutorials/envato-market-wordpress-plugin-for-theme-updates/' target='_blank'>" . esc_html__( "documentation", 'corpus' ) . "</a>.";

			$message .=  '<br/><span><a href="' .esc_url( wp_nonce_url( add_query_arg( 'corpus-eutf-dismiss', 'dismiss_envato_market_notice' ), 'corpus-eutf-dismiss-' . esc_attr( get_current_user_id() ) ) ) . '" class="dismiss-notice" target="_parent">' . esc_html__( "Dismiss this notice", 'corpus' ) . '</a><span>';

			add_settings_error(
				'eut-envato-market-message',
				'plugins_update_required',
				$message,
				'updated'
			);
			if ( 'options-general' !== $GLOBALS['current_screen']->parent_base ) {
				settings_errors( 'eut-envato-market-message' );
			}

		}
	}

}
add_action( 'admin_notices', 'corpus_eutf_admin_notices' );

/**
 * Dismiss notices and update user meta data
 */
function corpus_eutf_notice_dismiss() {
	if ( isset( $_GET['corpus-eutf-dismiss'] ) && check_admin_referer( 'corpus-eutf-dismiss-' . get_current_user_id() ) ) {
		$dismiss = $_GET['corpus-eutf-dismiss'];
		if ( 'dismiss_envato_market_notice' == $dismiss ) {
			update_user_meta( get_current_user_id(), 'corpus_eutf_dismissed_notice_envato_market' , 1 );
		} else if ( 'dismiss_update_plugins_notice' == $dismiss ) {
			update_user_meta( get_current_user_id(), 'corpus_eutf_dismissed_notice_update_plugins' , 1 );
		}
	}
}
add_action( 'admin_head', 'corpus_eutf_notice_dismiss' );

/**
 * Delete metadata for admin notices when switching themes
 */
function corpus_eutf_update_dismiss() {
	delete_metadata( 'user', null, 'corpus_eutf_dismissed_notice_envato_market', null, true );
	delete_metadata( 'user', null, 'corpus_eutf_dismissed_notice_update_plugins', null, true );
}
add_action( 'switch_theme', 'corpus_eutf_update_dismiss' );


//Omit closing PHP tag to avoid accidental whitespace output errors.
