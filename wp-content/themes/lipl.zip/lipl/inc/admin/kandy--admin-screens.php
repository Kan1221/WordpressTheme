<?php

/*
*	Admin screen functions
*
* 	@version	1.0
* 	@author		Euthemians Team
* 	@URI		http://euthemians.com
*/

function corpus_eutf_admin_menu(){
	if ( current_user_can( 'edit_theme_options' ) ) {
		add_menu_page( 'Corpus', 'Corpus', 'edit_theme_options', 'corpus', 'corpus_eutf_admin_page_welcome', get_template_directory_uri() .'/includes/images/adminmenu/theme.png', 4 );
		add_submenu_page( 'corpus', esc_html__('Welcome','corpus'), esc_html__('Welcome','corpus'), 'edit_theme_options', 'corpus', 'corpus_eutf_admin_page_welcome' );
		add_submenu_page( 'corpus', esc_html__('Status','corpus'), esc_html__('Status','corpus'), 'edit_theme_options', 'corpus-status', 'corpus_eutf_admin_page_status' );
		add_submenu_page( 'corpus', esc_html__( 'Custom Sidebars', 'corpus' ), esc_html__( 'Custom Sidebars', 'corpus' ), 'edit_theme_options','corpus-sidebars','corpus_eutf_admin_page_sidebars');
		add_submenu_page( 'corpus', esc_html__( 'Import Demos', 'corpus' ), esc_html__( 'Import Demos', 'corpus' ), 'edit_theme_options','corpus-import','corpus_eutf_admin_page_import');
	}
}

add_action( 'admin_menu', 'corpus_eutf_admin_menu' );


function corpus_eutf_tgmpa_plugins_links(){
	corpus_eutf_print_admin_links('plugins');
}
add_action( 'corpus_eutf_before_tgmpa_plugins', 'corpus_eutf_tgmpa_plugins_links' );

function corpus_eutf_admin_page_welcome(){
	require_once get_template_directory() . '/includes/admin/pages/eut-admin-page-welcome.php';
}
function corpus_eutf_admin_page_status(){
	require_once get_template_directory() . '/includes/admin/pages/eut-admin-page-status.php';
}
function corpus_eutf_admin_page_sidebars(){
	require_once get_template_directory() . '/includes/admin/pages/eut-admin-page-sidebars.php';
}
function corpus_eutf_admin_page_import(){
	require_once get_template_directory() . '/includes/admin/pages/eut-admin-page-import.php';
}

function corpus_eutf_print_admin_links( $active_tab = 'status' ) {
?>
<h2 class="nav-tab-wrapper">
	<a href="?page=corpus" class="nav-tab <?php echo 'welcome' == $active_tab ? 'nav-tab-active' : ''; ?>"><?php echo esc_html__('Welcome','corpus'); ?></a>
	<a href="?page=corpus-status" class="nav-tab <?php echo 'status' == $active_tab ? 'nav-tab-active' : ''; ?>"><?php echo esc_html__('Status','corpus'); ?></a>
	<a href="?page=corpus-sidebars" class="nav-tab <?php echo 'sidebars' == $active_tab ? 'nav-tab-active' : ''; ?>"><?php echo esc_html__('Custom Sidebars','corpus'); ?></a>
	<a href="?page=corpus-import" class="nav-tab <?php echo 'import' == $active_tab ? 'nav-tab-active' : ''; ?>"><?php echo esc_html__('Import Demos','corpus'); ?></a>
	<a href="?page=corpus-tgmpa-install-plugins" class="nav-tab <?php echo 'plugins' == $active_tab ? 'nav-tab-active' : ''; ?>"><?php echo esc_html__('Theme Plugins','corpus'); ?></a>
	<?php do_action( 'corpus_eutf_admin_links', $active_tab ); ?>
</h2>
<?php
}

//Omit closing PHP tag to avoid accidental whitespace output errors.